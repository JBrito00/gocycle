create function listexistingbikes()
    returns TABLE(id character varying, weight double precision, model character varying, brand character varying, gear_system character varying, status character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT id, weight, model, brand, gear_system, status FROM Bicycle;
END;
$$;

alter function listexistingbikes() owner to t42dg22;

