create function checkbikeavailability(p_bikeid integer, p_datetime character varying) returns boolean
    language plpgsql
as
$$
BEGIN
    -- Assuming there is a 'reservations' table with 'bike_id' and 'end_date'
    -- and we want to check if there are any reservations for this bike after the given date

    IF EXISTS (SELECT 1
               FROM reservation
               WHERE bicycle_id = p_bikeId
                 AND end_date  >= p_dateTime::timestamp
                 AND start_date <= p_dateTime::timestamp) THEN
        RETURN FALSE; -- Bike is not available
    ELSE
        RETURN TRUE; -- Bike is available
    END IF;
END;
$$;

alter function checkbikeavailability(integer, varchar) owner to t42dg22;

