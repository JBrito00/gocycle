create function get_existing_bookings()
    returns TABLE(booking_id integer, customer_id integer, bike_id integer, start_time timestamp without time zone, end_time timestamp without time zone, price numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            booking_id,
            customer_id,
            bike_id,
            start_time,
            end_time,
            price
        FROM
            reservation;
END;
$$;

alter function get_existing_bookings() owner to t42dg22;

