create function cancel_booking(reservation_id integer) returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM reservation
    WHERE reservation_number = reservation_id;
END;
$$;

alter function cancel_booking(integer) owner to t42dg22;

