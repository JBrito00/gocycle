create procedure createcustomer(IN name character varying, IN address character varying, IN email character varying, IN phone character varying, IN cc character varying, IN nationality character varying)
    language plpgsql
as
$$
BEGIN
    INSERT INTO customer (name, address, email, phone, cc, nationality)
    VALUES (name, address, email, phone, cc, nationality);
END;
$$;

alter procedure createcustomer(varchar, varchar, varchar, varchar, varchar, varchar) owner to t42dg22;

