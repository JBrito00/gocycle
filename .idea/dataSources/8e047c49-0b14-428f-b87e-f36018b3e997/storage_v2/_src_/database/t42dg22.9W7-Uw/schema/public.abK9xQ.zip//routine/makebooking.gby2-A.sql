create procedure makebooking(IN p_customerid integer, IN p_bikeid integer, IN p_startdatetime timestamp without time zone, IN p_enddatetime timestamp without time zone, IN p_price double precision)
    language plpgsql
as
$$
BEGIN
    -- Assuming you have a bookings table with the necessary columns
    INSERT INTO reservation (start_date, end_date, bicycle_id, customer_id, price)
    VALUES (p_startDateTime, p_endDateTime,  p_bikeId, p_customerId, p_price);

    -- You can add any additional logic here, like updating availability, etc.

    COMMIT;
END;
$$;

alter procedure makebooking(integer, integer, timestamp, timestamp, double precision) owner to t42dg22;

