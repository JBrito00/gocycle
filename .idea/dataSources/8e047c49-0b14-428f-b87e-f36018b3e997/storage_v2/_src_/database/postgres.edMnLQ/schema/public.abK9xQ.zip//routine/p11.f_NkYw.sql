create procedure p11(VARIADIC integer[])
    language plpgsql
as
$$
declare 
	value int;
BEGIN
  FOREACH value IN ARRAY $1
  loop
	INSERT INTO y(val) VALUES (value);			
  END LOOP;
end;
$$;

alter procedure p11(integer[]) owner to t42dg16;

