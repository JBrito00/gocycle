create function is_valid_email(email character varying) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN email ~* '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$';
END;
$$;

alter function is_valid_email(varchar) owner to t42dg16;

