create procedure p1(VARIADIC integer[])
    language plpgsql
as
$$
BEGIN
    -- Insert values from the variadic array into the table
    FOR i IN 1..array_length($1, 1) LOOP
        -- Insert into the table only if it doesn't exist to maintain the UNIQUE constraint
        INSERT INTO T (val) VALUES ($1[i])
        ON CONFLICT (val) DO NOTHING; -- Avoiding errors if the value already exists
    END LOOP;
END;
$$;

alter procedure p1(integer[]) owner to t42dg20;

