create procedure make_reservation(IN p_storeid integer, IN p_starttimestamp timestamp without time zone, IN p_endtimestamp timestamp without time zone, IN p_value numeric, IN p_bikeid integer, IN p_customerid integer)
    language plpgsql
as
$$
DECLARE
new_reservation_id INTEGER;
BEGIN
    -- Check if the bike is available
    IF NOT EXISTS (
        SELECT 1 FROM RESERVA
        WHERE bicicleta = p_bikeId
          AND (dtinicio < p_endTimestamp AND dtfim > p_startTimestamp)
    ) THEN
        -- If the bike is available, make a reservation
        INSERT INTO RESERVA (loja, dtinicio, dtfim, valor, bicicleta)
        VALUES (p_storeId, p_startTimestamp, p_endTimestamp, p_value, p_bikeId)
        RETURNING noreserva INTO new_reservation_id;

        -- Insert into CLIENTERESERVA
INSERT INTO CLIENTERESERVA (cliente, reserva, loja)
VALUES (p_customerId, new_reservation_id, p_storeId);

-- Update the bike status to 'reserved'
UPDATE BICICLETA SET estado = 'ocupado' WHERE id = p_bikeId;
ELSE
        -- If the bike is not available, raise an exception
        RAISE EXCEPTION 'Bike is not available for the selected time period.';
END IF;
END;
$$;

alter procedure make_reservation(integer, timestamp, timestamp, numeric, integer, integer) owner to t42dg17;

