create function checkbikeavailability()
    returns TABLE(id integer, peso numeric, raio integer, modelo character varying, marca character varying, mudanca integer, estado character varying, atrdisc character, dispositivo integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM BICICLETA WHERE BICICLETA.estado = 'livre';
END;
$$;

alter function checkbikeavailability() owner to t42dg17;

