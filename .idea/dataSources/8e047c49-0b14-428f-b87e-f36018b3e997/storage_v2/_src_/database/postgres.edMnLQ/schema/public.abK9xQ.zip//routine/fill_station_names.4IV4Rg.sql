create function fill_station_names() returns trigger
    language plpgsql
as
$$
begin
    -- Look up the start station name
    SELECT station_name INTO NEW.start_station_name FROM station WHERE station_id = NEW.start_station_id;
    
    -- Look up the end station name
    SELECT station_name INTO NEW.end_station_name FROM station WHERE station_id = NEW.end_station_id;
    
    RETURN NEW;
END;
$$;

alter function fill_station_names() owner to t42dg20;

