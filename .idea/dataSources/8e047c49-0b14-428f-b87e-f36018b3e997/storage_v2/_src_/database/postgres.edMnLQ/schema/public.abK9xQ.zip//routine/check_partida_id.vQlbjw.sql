create function check_partida_id() returns trigger
    language plpgsql
as
$$
    begin
        -- *new* is a reference to the new row that triggered the trigger function to execute,
        -- either by update or insert in this context
        if (exists (select 1 from PartidaMultiJogador where partidaid = new.partidaid)
            or exists (select 1 from PartidaNormal where partidaid = new.partidaid))
            then raise exception 'This id already exists in one of the Partida child tables';
        end if;
        return new;
    end;
    $$;

alter function check_partida_id() owner to postgres;

