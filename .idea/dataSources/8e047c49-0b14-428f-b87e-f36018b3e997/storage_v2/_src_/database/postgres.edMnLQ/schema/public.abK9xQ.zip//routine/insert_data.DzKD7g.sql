create procedure insert_data(IN a integer, IN b integer)
    language sql
as
$$

INSERT INTO t(val) VALUES (a);
INSERT INTO t(val) VALUES (b); 

$$;

alter procedure insert_data(integer, integer) owner to t42dg27;

