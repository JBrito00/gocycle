create function check_jogador_region(partida_id integer, jogador_id integer) returns boolean
    language plpgsql
as
$$
    begin
        return exists(
            select 1
            from Partida p join Jogador j on j.id = jogador_id and p.id = partida_id
            where p.regiao = j.regiao
        );
    end;
    $$;

alter function check_jogador_region(integer, integer) owner to postgres;

