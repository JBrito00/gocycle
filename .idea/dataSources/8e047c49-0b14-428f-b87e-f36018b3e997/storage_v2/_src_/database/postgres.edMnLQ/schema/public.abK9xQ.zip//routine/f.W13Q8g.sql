create function f(p character) returns integer
    language sql
RETURN (character_length(p) * 2);

alter function f(char) owner to t42dg16;

