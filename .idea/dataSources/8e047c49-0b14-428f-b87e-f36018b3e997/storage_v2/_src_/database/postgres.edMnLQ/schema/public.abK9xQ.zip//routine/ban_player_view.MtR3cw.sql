create function ban_player_view() returns trigger
    language plpgsql
as
$$
BEGIN
    update jogador set estado='Banido' where id = old.player_id;
    return old;
end;
$$;

alter function ban_player_view() owner to postgres;

